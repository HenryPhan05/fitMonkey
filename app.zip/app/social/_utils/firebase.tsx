// app/utils/firebase.ts
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

//Initialize App safely
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

//Initialize Firestore
const db = getFirestore(app);

//Initialize Storage safely (checks if bucket exists to avoid the "No bucket" crash)
const storage = firebaseConfig.storageBucket ? getStorage(app) : null;

export { app, db, storage };